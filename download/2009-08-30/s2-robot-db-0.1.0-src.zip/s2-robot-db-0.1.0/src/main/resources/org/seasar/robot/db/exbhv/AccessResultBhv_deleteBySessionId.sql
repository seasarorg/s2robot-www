delete from ACCESS_RESULT
/*BEGIN*/where 
	/*IF pmb != null*/SESSION_ID = /*pmb*/'20090704161034370'/*END*/
/*END*/
