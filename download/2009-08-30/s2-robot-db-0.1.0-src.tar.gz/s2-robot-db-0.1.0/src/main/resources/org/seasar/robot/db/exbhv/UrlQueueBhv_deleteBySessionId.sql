
delete from URL_QUEUE
/*BEGIN*/where 
	/*IF pmb != null*/SESSION_ID = /*pmb*/'20090704161034370'/*END*/
/*END*/
